package com.quizgram.quizgrambackend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class QuizgramBackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(QuizgramBackendApplication.class, args);
	}

}
